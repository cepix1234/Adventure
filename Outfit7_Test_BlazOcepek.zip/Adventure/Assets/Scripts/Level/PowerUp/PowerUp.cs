﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour {

    // Use this for initialization
    public string type;
    public GameObject gun;
    public int helthUp;
}
